STEVE’S CARPET CLEANING SERVICE — WEBSITE

Business phone: 07526 142521
WhatsApp link: https://wa.me/447526142521
Service area: Pinxton and surrounding areas

BEFORE PUBLISHING
1. Open index.html in a text editor.
2. In the script near the bottom, replace REPLACE_WITH_YOUR_EMAIL with the business email address that should receive enquiries.
3. Check the phone number, WhatsApp link and service area are correct.

CONTACT FORM
The starter form opens the visitor’s email app with their enquiry pre-filled. It does not store enquiries or send them automatically. Add your email address in the code before publishing.

PUBLISH FREE WITH GITHUB PAGES
1. Create/sign in to a free account at https://github.com
2. Create a new public repository named steves-carpet-cleaning.
3. Upload index.html to the top level of the repository.
4. Open Settings → Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Choose the main branch and /(root), then Save.
7. Your free address will look like https://YOUR-USERNAME.github.io/steves-carpet-cleaning/

A free hosting address is included; a custom .com domain usually costs extra. Test the site and links on a phone before sharing it.
